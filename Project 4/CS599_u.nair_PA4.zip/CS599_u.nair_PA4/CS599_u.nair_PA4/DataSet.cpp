#include "precompiled.h"
#include "DataSet.h"


DataSet::DataSet()
{
}


DataSet::~DataSet()
{
}
