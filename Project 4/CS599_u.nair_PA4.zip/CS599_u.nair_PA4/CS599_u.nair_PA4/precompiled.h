#pragma once


#include <iostream>
#include <vector>
#include <map>
#include <sstream>
#include <cfloat>
#include <unordered_map>
#include <fstream>
#include <numeric>
#include <algorithm>