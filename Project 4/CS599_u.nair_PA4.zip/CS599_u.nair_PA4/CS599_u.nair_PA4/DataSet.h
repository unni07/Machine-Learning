#pragma once
class DataSet
{
public:
	DataSet();
	~DataSet();
};

