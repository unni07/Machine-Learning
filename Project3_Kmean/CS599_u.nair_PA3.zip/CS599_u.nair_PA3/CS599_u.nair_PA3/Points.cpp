#include "Points.h"


Points::Points()
{
	position.xposition = position.yposition  = 0.0f;
	clusterGroupNum = 0;
}


Points::~Points()
{
}
