#include "positionVector.h"


positionVector::positionVector()
{
	xposition = 0;
	yposition = 0;
}


positionVector::~positionVector()
{
}
