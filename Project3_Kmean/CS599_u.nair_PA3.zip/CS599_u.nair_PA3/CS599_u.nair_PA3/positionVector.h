#pragma once
/*this is just a simple vector class to hold the position*/
class positionVector
{
public:
	float xposition;
	float yposition;
	positionVector();
	~positionVector();
};

